import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

//Light Mode
final Color textWhite = HexColor('#E0E0E0');
final Color textGreen = HexColor('#388E3C');
final Color backgroundWhite = HexColor('#E0E0E0');
final Color backgroundGreen = HexColor('#388E3C');

//Dark Mode
final Color textGreenF = HexColor('#38b387');
final Color textGrey = HexColor('#93a59e');
final Color backgroundGrey = HexColor('#2e3951');
final Color backgroundGreyDark = HexColor('#212b41');

double numberSize = 40;
