import 'package:flutter/material.dart';
import 'constants.dart';
import 'package:math_expressions/math_expressions.dart';

void main() {
  runApp(CalculatorApplication());
}

class CalculatorApplication extends StatefulWidget {
  const CalculatorApplication({super.key});

  @override
  State<CalculatorApplication> createState() => _CalculatorApplicationState();
}

class _CalculatorApplicationState extends State<CalculatorApplication> {
  var inputUser = '';
  var result = '';
  void buttonPressed(String text) {
    setState(() {
      inputUser += text;
    });
  }

  Widget getRow({
    required String text1,
    required String text2,
    required String text3,
    required String text4,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Container(
          width: 80.0,
          height: 80.0,
          child: TextButton(
            style: TextButton.styleFrom(
              shape: CircleBorder(
                side: BorderSide(width: 0, color: Colors.transparent),
              ),
              backgroundColor: getBackgroundColor(text1),
            ),
            onPressed: () {
              if (text1 == 'ac') {
                setState(() {
                  result = '';
                  inputUser = '';
                });
              } else {
                buttonPressed(text1);
              }
            },
            child: Padding(
              padding: EdgeInsets.all(3),
              child: Text(
                text1,
                textAlign: TextAlign.center,
                style:
                    TextStyle(fontSize: numberSize, color: getTextcolor(text1)),
              ),
            ),
          ),
        ),
        Container(
          width: 80.0,
          height: 80.0,
          child: TextButton(
            style: TextButton.styleFrom(
              shape: CircleBorder(
                side: BorderSide(width: 0, color: Colors.transparent),
              ),
              backgroundColor: getBackgroundColor(text2),
            ),
            onPressed: () {
              if (text2 == 'ce') {
                setState(() {
                  if (inputUser.length > 0)
                    inputUser = inputUser.substring(0, inputUser.length - 1);
                });
              } else {
                buttonPressed(text2);
              }
            },
            child: Padding(
              padding: EdgeInsets.all(3),
              child: Text(
                text2,
                textAlign: TextAlign.center,
                style:
                    TextStyle(fontSize: numberSize, color: getTextcolor(text2)),
              ),
            ),
          ),
        ),
        Container(
          width: 80.0,
          height: 80.0,
          child: TextButton(
            style: TextButton.styleFrom(
              shape: CircleBorder(
                side: BorderSide(width: 0, color: Colors.transparent),
              ),
              backgroundColor: getBackgroundColor(text3),
            ),
            onPressed: () {
              if (text3 == 'ce') {
                setState(() {
                  if (inputUser.length > 0)
                    inputUser = inputUser.substring(0, inputUser.length - 1);
                });
              } else {
                buttonPressed(text3);
              }
            },
            child: Padding(
              padding: EdgeInsets.all(3),
              child: Text(
                text3,
                textAlign: TextAlign.center,
                style:
                    TextStyle(fontSize: numberSize, color: getTextcolor(text3)),
              ),
            ),
          ),
        ),
        Container(
          width: 80.0,
          height: 80.0,
          child: TextButton(
            style: TextButton.styleFrom(
              shape: CircleBorder(
                side: BorderSide(width: 0, color: Colors.transparent),
              ),
              backgroundColor: getBackgroundColor(text4),
            ),
            onPressed: () {
              if (text4 == '=') {
                Parser parser = Parser();
                Expression expression = parser.parse(inputUser);
                ContextModel contextModel = ContextModel();
                double aval =
                    expression.evaluate(EvaluationType.REAL, contextModel);
                setState(() {
                  result = aval.toString();
                });
              } else {
                buttonPressed(text4);
              }
            },
            child: Padding(
              padding: EdgeInsets.all(3),
              child: Text(
                text4,
                textAlign: TextAlign.center,
                style:
                    TextStyle(fontSize: numberSize, color: getTextcolor(text4)),
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: Container(
                  color: Colors.white,
                  height: 100,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Padding(
                        padding: EdgeInsets.all(8),
                        child: Text(
                          inputUser,
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 52),
                          textAlign: TextAlign.end,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(8),
                        child: Text(
                          result,
                          style: TextStyle(fontSize: 80, color: textGreen),
                          textAlign: TextAlign.end,
                        ),
                      )
                    ],
                  ),
                ),
                flex: 4,
              ),
              Container(
                width: 250,
                child: Divider(
                  color: Colors.black,
                  thickness: 1,
                ),
              ),
              Expanded(
                child: Container(
                  color: Colors.grey[200],
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      getRow(text1: 'ac', text2: 'ce', text3: '%', text4: '/'),
                      getRow(text1: '7', text2: '8', text3: '9', text4: '*'),
                      getRow(text1: '4', text2: '5', text3: '6', text4: '-'),
                      getRow(text1: '1', text2: '2', text3: '3', text4: '+'),
                      getRow(text1: '00', text2: '0', text3: '.', text4: '='),
                    ],
                  ),
                ),
                flex: 6,
              ),
            ],
          ),
        ),
      ),
    );
  }

  bool isOperator(String text) {
    var list = ['ac', 'ce', '%', '/', '*', '-', '+', '='];
    for (var item in list) {
      if (text == item) {
        return true;
      }
    }
    return false;
  }

  Color getBackgroundColor(String text) {
    if (isOperator(text)) {
      return backgroundGreen;
    } else {
      return backgroundWhite;
    }
  }

  Color getTextcolor(String text) {
    if (isOperator(text)) {
      return textWhite;
    } else {
      return textGreen;
    }
  }
}
